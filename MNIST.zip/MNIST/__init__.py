"""FedOps Silo Torch"""
